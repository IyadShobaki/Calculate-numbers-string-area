﻿Public Class part2bClass
    Inherits part2Class
    Public Overrides Function Calculate(ByVal Num1 As Integer, ByVal Num2 As Integer) As Integer
        Return Num1 * Num2
    End Function
End Class
