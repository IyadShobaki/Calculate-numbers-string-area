﻿Public Class part1Class2

    Public Function Add(ByRef s1 As String, ByRef s2 As String, Optional ByRef s3 As String = "") As String
        Return s1 + s2 + s3


    End Function
End Class

