﻿Public Class part1Class

    Public Function Add(ByVal num1 As Integer, ByVal num2 As Integer, Optional ByVal num3 As Integer = 0) As Integer
        Return num1 + num2 + num3


    End Function
    Public Function Add(ByVal s1 As String, ByVal s2 As String, Optional ByVal s3 As String = "") As String
        Return s1 + s2 + s3


    End Function
End Class
